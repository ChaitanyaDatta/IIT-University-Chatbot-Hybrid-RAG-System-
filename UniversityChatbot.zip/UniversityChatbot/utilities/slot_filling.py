# Domain-specific query validation with zero hardcoded domain values.
# - Contacts strong units  → built from ES department names at startup
# - Calendar event tokens  → built from ES event_name values at startup
# - Tuition school/fee     → built from ES school + fee_name values at startup
# - Documents topics       → loaded from utilities/config/documents_topics.json

import json
import re
import string
import logging
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

try:
    from utilities.clarification_options import options_cache
    _OPTIONS_AVAILABLE = True
except Exception:
    _OPTIONS_AVAILABLE = False
    options_cache = None

# ── Documents config ──────────────────────────────────────────────────────────

# Loads topic and doc_type keywords from JSON — avoids hardcoding policy vocabulary in Python.
def _load_documents_config() -> Dict:
    for config_path in [
        Path(__file__).resolve().parent / "config" / "documents_topics.json",
        Path(__file__).resolve().parent.parent / "utilities" / "config" / "documents_topics.json",
    ]:
        if config_path.exists():
            try:
                with open(config_path) as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Could not load documents_topics.json: {e}")
    logger.warning("documents_topics.json not found — document validation will be permissive.")
    return {"topic_keywords": [], "doc_type_keywords": []}

_DOCS_CONFIG = _load_documents_config()

# ── Vocabulary config ─────────────────────────────────────────────────────────

def _load_vocabulary() -> dict:
    for config_path in [
        Path(__file__).resolve().parent / "config" / "vocabulary.json",
        Path(__file__).resolve().parent.parent / "utilities" / "config" / "vocabulary.json",
    ]:
        if config_path.exists():
            try:
                with open(config_path) as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Could not load vocabulary.json: {e}")
    logger.warning("vocabulary.json not found — using inline fallbacks.")
    return {}

_VOCAB = _load_vocabulary()

# ── Pattern builder ───────────────────────────────────────────────────────────

# Builds a word-boundary regex from a list of terms. Returns None if the list is empty.
def _build_pattern(terms: List[str], flags=re.IGNORECASE) -> "re.Pattern | None":
    clean = [t.lower().strip() for t in terms if t and t.strip()]
    if not clean:
        return None
    escaped = sorted([re.escape(t) for t in clean], key=len, reverse=True)
    return re.compile(r"\b(" + "|".join(escaped) + r")\b", flags)

# ── Department alias expansion ────────────────────────────────────────────────

# Generates short-form aliases from full ES department names so partial queries
# like "computer science" match "Department of Computer Science".
# Strategy: strip known prefixes, extract suffix from "X College/School of Y",
# then append a manual alias list for common short forms used in student queries.
def _expand_department_aliases(departments: List[str]) -> List[str]:
    STRIP_PREFIXES = _VOCAB.get("department_strip_prefixes", [
        "department of ", "college of ", "school of ", "institute of ", "office of ",
    ])
    INFIX_RE = re.compile(r".+\b(?:college|school|institute)\b of (.+)", re.IGNORECASE)
    GENERIC_SKIP = set(_VOCAB.get("department_generic_skip", ["law", "design", "letters", "science", "arts"]))

    seen = {d.lower() for d in departments}
    aliases = list(departments)

    for dept in departments:
        lower = dept.lower().strip()
        for prefix in STRIP_PREFIXES:
            if lower.startswith(prefix):
                short = lower[len(prefix):].strip()
                if short and short not in seen:
                    aliases.append(short)
                    seen.add(short)
                break
        m = INFIX_RE.match(lower)
        if m:
            short = m.group(1).strip()
            if short and short not in seen and short not in GENERIC_SKIP:
                aliases.append(short)
                seen.add(short)

    MANUAL = _VOCAB.get("department_manual_aliases", [
        "financial aid", "registrar", "admissions", "bursar", "advising",
        "it helpdesk", "helpdesk", "kent", "kent law", "stuart", "armour",
        "lewis", "kaplan", "pritzker", "wiser", "ifsh",
        "student accounting", "graduate admission", "undergraduate admission",
        "student affairs", "academic affairs", "global services",
        "office of the registrar", "student accounting office",
        "dean of students", "dean of admissions", "dean of libraries",
    ])
    for alias in MANUAL:
        if alias not in seen:
            aliases.append(alias)
            seen.add(alias)

    return aliases


_GENERIC_FEE_NAMES: set = set(_VOCAB.get("tuition_generic_fee_names", ["tuition", "fees", "fee", "cost", "costs", "rate", "rates"]))

# Truncates fee names to the first 2 words; optionally excludes generic names
# that don't add retrieval specificity.
def _shorten_fee_names(fee_names: List[str], exclude_generic: bool = False) -> List[str]:
    result = []
    for f in fee_names:
        lower = f.lower().strip()
        if exclude_generic and lower in _GENERIC_FEE_NAMES:
            continue
        words = lower.split()
        short = " ".join(words[:2]) if len(words) > 2 else lower
        short = short.rstrip(":.,;")
        if short and (not exclude_generic or short not in _GENERIC_FEE_NAMES):
            result.append(short)
    return result

# ── Lazy pattern cache ────────────────────────────────────────────────────────

class _PatternCache:
    def __init__(self):
        self._contacts_strong  = None
        self._calendar_events  = None
        self._tuition_anchor   = None
        self._tuition_specific = None
        self._docs_topic       = None
        self._docs_type        = None

    def _get(self, attr: str, builder):
        val = getattr(self, attr)
        if val is None or val == []:
            result = builder()
            setattr(self, attr, result if result else [])
        return getattr(self, attr)

    @property
    def contacts_strong(self):
        def _build():
            departments = options_cache.contact_departments if _OPTIONS_AVAILABLE else []
            return _build_pattern(_expand_department_aliases(departments))
        return self._get("_contacts_strong", _build)

    @property
    def calendar_events(self):
        return self._get("_calendar_events", lambda: _build_pattern(
            options_cache.calendar_event_tokens if _OPTIONS_AVAILABLE else []
        ))

    @property
    def tuition_anchor(self):
        def _build():
            schools    = options_cache.tuition_schools   if _OPTIONS_AVAILABLE else []
            fee_names  = options_cache.tuition_fee_names if _OPTIONS_AVAILABLE else []
            levels     = options_cache.tuition_levels    if _OPTIONS_AVAILABLE else []
            years      = options_cache.tuition_years     if _OPTIONS_AVAILABLE else []
            structural = _VOCAB.get("tuition_structural_vocab", [
                "tuition", "fees", "fee", "rate", "rates", "cost", "costs",
                "price", "prices", "charge", "charges", "per credit", "credit hour",
                "mandatory", "activity fee", "health insurance", "student service",
                "graduate", "undergraduate", "full-time", "part-time",
                "full time", "part time", "billing", "llm", "mdes", "mdm",
                "per semester", "per term", "upass", "u-pass",
                "deposit", "admissions deposit", "application fee",
                "refund", "payment", "installment",
            ])
            return _build_pattern(schools + _shorten_fee_names(fee_names) + levels + years + structural)
        return self._get("_tuition_anchor", _build)

    # ES-derived anchors only (school, fee name, level, year).
    # Used to detect queries that only match structural vocabulary.
    @property
    def tuition_specific(self):
        def _build():
            schools   = options_cache.tuition_schools   if _OPTIONS_AVAILABLE else []
            fee_names = options_cache.tuition_fee_names if _OPTIONS_AVAILABLE else []
            levels    = options_cache.tuition_levels    if _OPTIONS_AVAILABLE else []
            years     = options_cache.tuition_years     if _OPTIONS_AVAILABLE else []
            extra = _VOCAB.get("tuition_specific_extras", ["upass", "u-pass", "deposit", "application fee"])
            return _build_pattern(schools + _shorten_fee_names(fee_names, exclude_generic=True) + levels + years + extra)
        return self._get("_tuition_specific", _build)

    @property
    def docs_topic(self):
        return self._get("_docs_topic", lambda: _build_pattern(
            _DOCS_CONFIG.get("topic_keywords", [])
        ))

    @property
    def docs_type(self):
        return self._get("_docs_type", lambda: _build_pattern(
            _DOCS_CONFIG.get("doc_type_keywords", [])
        ))

_patterns = _PatternCache()

# ── Shared helpers ────────────────────────────────────────────────────────────

def _options(values: List[str], max_items: int = 15) -> List[str]:
    if not _OPTIONS_AVAILABLE or not values:
        return []
    return values[:max_items]

def _clarify(message: str, options: List[str] = None) -> Dict[str, Any]:
    return {"needs_clarification": True, "message": message, "options": options or []}

def _match(pattern, text: str) -> bool:
    return bool(pattern.search(text)) if pattern else False

# ── Structural patterns (always fixed — not derived from ES) ──────────────────

_CALENDAR_TERM          = _build_pattern(_VOCAB.get("calendar_term_words", ["spring", "fall", "summer", "winter", "semester", "term"]))
_CALENDAR_WEAK          = _build_pattern(_VOCAB.get("calendar_weak_words", ["deadline", "due", "start", "end", "begin", "close", "week", "weeks", "first day", "last day", "first class", "last class", "orientation"]))
_CALENDAR_STRONG_HOLIDAY= _build_pattern(_VOCAB.get("calendar_holidays", ["thanksgiving", "christmas", "labor day", "memorial day", "juneteenth", "independence day", "martin luther king", "mlk", "new year", "spring break", "fall break", "winter break", "holiday", "holidays", "university holiday", "paid holiday", "floating holiday"]))
_CALENDAR_DATE          = _build_pattern(_VOCAB.get("calendar_date_words", ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"]))
_CALENDAR_SPECIFIC_TERM = _build_pattern(_VOCAB.get("calendar_specific_terms", ["spring", "fall", "summer", "winter", "term a", "term b", "coursera"]))
_CONTACT_SLOTS          = _build_pattern(_VOCAB.get("contact_slot_words", ["phone", "phones", "email", "emails", "call", "number", "numbers", "fax", "contact", "contacts", "address", "addresses", "handles", "handle", "manages", "manage", "responsible", "reach", "in charge", "who do i", "who should i", "who can i", "who is", "who's", "is there a", "are there"]))
_LOCATION_SLOTS         = _build_pattern(_VOCAB.get("location_slot_words", ["where", "building", "buildings", "location", "locations", "room", "rooms", "campus", "floor", "floors"]))
_GENERIC_UNIT           = _build_pattern(_VOCAB.get("generic_unit_words", ["department", "departments", "office", "offices", "program", "programs", "school", "schools", "college", "colleges"]))
_GENERIC_MONEY          = _build_pattern(_VOCAB.get("generic_money_words", ["pay", "paying", "money", "afford", "expensive", "cheap", "bill", "billing"]))
_GENERIC_DOC            = _build_pattern(_VOCAB.get("generic_doc_words", ["document", "documents", "info", "information"]))

# Curated contacts clarification list (offices/schools shown when the query is underspecified).
CONTACT_DEPT_PICKER_OPTIONS: List[str] = _VOCAB.get("contact_dept_picker_options", [
    "Registrar", "Financial Aid", "Student Accounting", "Academic Affairs",
    "Admissions", "Student Affairs", "Global Services",
    "Armour College of Engineering", "College of Computing",
    "College of Architecture", "Chicago-Kent College of Law",
    "Stuart School of Business", "Lewis College of Science and Letters",
    "Institute of Design", "Computer Science", "Physics", "Chemistry",
])


# Returns True when the user message selects one of the contacts clarification picker options.
# Handles exact label match or a single-word match, punctuation-tolerant.
def contact_reply_matches_picker_option(text: str) -> bool:
    raw = (text or "").strip()
    if not raw:
        return False
    lower = raw.lower()
    if any(lower == o.lower() for o in CONTACT_DEPT_PICKER_OPTIONS):
        return True
    words = raw.split()
    if len(words) == 1:
        w = words[0].strip(string.punctuation).lower()
        return any(w == o.lower() for o in CONTACT_DEPT_PICKER_OPTIONS)
    return False


# Substring match for multi-word picker options (e.g. "Chicago-Kent College of Law").
def _mentions_dept_picker_option(q_lower: str) -> bool:
    return any(opt.lower() in q_lower for opt in CONTACT_DEPT_PICKER_OPTIONS)


# ── Calendar ──────────────────────────────────────────────────────────────────

def calendar_query_validation(query: str) -> Dict[str, Any]:
    q = (query or "").lower()
    term_opts = _options(options_cache.calendar_terms if _OPTIONS_AVAILABLE else [])

    if len(q.split()) <= 1:
        return _clarify("Could you provide a bit more detail about your question?", term_opts)

    has_specific_term = bool(_CALENDAR_SPECIFIC_TERM.search(q))
    has_weak_event = bool(_CALENDAR_WEAK.search(q))
    has_strong_event = _match(_patterns.calendar_events, q) or bool(_CALENDAR_STRONG_HOLIDAY.search(q))
    has_date = bool(_CALENDAR_DATE.search(q))
    has_specific_context = has_specific_term or has_date

    if has_strong_event and has_specific_context:
        return {"needs_clarification": False, "options": []}

    if bool(_CALENDAR_STRONG_HOLIDAY.search(q)):
        return {"needs_clarification": False, "options": []}

    if has_weak_event and not has_specific_context:
        return _clarify("Which semester or year are you referring to?", term_opts)

    if has_specific_context:
        return {"needs_clarification": False, "options": []}

    if bool(_CALENDAR_TERM.search(q)) and not has_specific_context:
        return _clarify("Which semester or year are you referring to?", term_opts)

    return _clarify(
        "Could you clarify what part of the academic calendar you are asking about? "
        "For example: a specific exam period, drop deadline, break, or graduation date.",
        term_opts,
    )


# ── Contacts ──────────────────────────────────────────────────────────────────

def contacts_query_validation(query: str) -> Dict[str, Any]:
    q = (query or "").lower()
    words = q.split()
    dept_opts = CONTACT_DEPT_PICKER_OPTIONS

    # One-word picker match is enough to search directly.
    if len(words) == 1:
        w0 = words[0].strip(string.punctuation).lower()
        if any(opt.lower() == w0 for opt in dept_opts):
            return {"needs_clarification": False, "options": []}
        return _clarify("Which department or office are you looking for?", dept_opts)

    has_strong_unit = _match(_patterns.contacts_strong, q)
    has_contact_slot = bool(_CONTACT_SLOTS.search(q))
    has_location_slot = bool(_LOCATION_SLOTS.search(q))
    has_generic_unit = bool(_GENERIC_UNIT.search(q))

    if has_strong_unit:
        return {"needs_clarification": False, "options": []}

    # Broad support asks ("who should I contact about X?") are answerable.
    if has_contact_slot and not has_generic_unit:
        return {"needs_clarification": False, "options": []}

    # Location question for a concrete unit — enough context to search.
    if has_location_slot and has_generic_unit and len(words) >= 4:
        return {"needs_clarification": False, "options": []}

    # Reformulated follow-ups or clarification answers that name a department.
    if _mentions_dept_picker_option(q):
        return {"needs_clarification": False, "options": []}

    return _clarify(
        "Could you specify which department or office and what kind of information you need?",
        dept_opts,
    )


# ── Tuition ───────────────────────────────────────────────────────────────────

_TUITION_LEVEL          = _build_pattern(_VOCAB.get("tuition_level_terms", ["graduate", "grad", "undergraduate", "undergrad", "masters", "doctoral", "phd", "llm", "mdes", "mdm"]))
_TUITION_SCHOOL_ALIASES = _build_pattern(_VOCAB.get("tuition_school_alias_terms", ["kent", "chicago-kent", "chicago kent", "law school", "stuart", "business school", "mies", "institute of design", "iep", "intensive english"]))


def tuition_query_validation(query: str) -> Dict[str, Any]:
    q = (query or "").lower()
    school_opts = _options(options_cache.tuition_schools if _OPTIONS_AVAILABLE else [])
    words = q.split()

    if len(words) <= 1:
        w = q.strip(string.punctuation)
        if school_opts and any(w == opt.lower() for opt in school_opts):
            return {"needs_clarification": False, "options": []}
        return _clarify("Which school or program are you asking about?", school_opts)

    has_anchor = _match(_patterns.tuition_anchor, q)
    has_specific = (
        _match(_patterns.tuition_specific, q)
        or bool(_TUITION_LEVEL.search(q))
        or bool(_TUITION_SCHOOL_ALIASES.search(q))
    )
    has_generic_money = bool(_GENERIC_MONEY.search(q))
    has_pricing_intent = bool(re.search(
        r"\b(tuition|fee|fees|cost|costs|rate|rates|price|prices|billing|bill|per credit|credit hour)\b", q
    ))

    # Overlap terms like "full-time" can trigger TUITION routing without real pricing intent.
    if has_anchor and not has_pricing_intent:
        return {"needs_clarification": False, "options": []}

    if has_specific:
        return {"needs_clarification": False, "options": []}

    if has_anchor and not has_specific:
        return _clarify("Could you specify which school or program level this is for?", school_opts)

    if has_generic_money:
        return _clarify(
            "Could you specify what you need about tuition and fees? "
            "For example: which school, program level, or a specific fee.",
            school_opts,
        )

    return _clarify(
        "Could you specify what you need about tuition and fees? "
        "For example: which school, program level, or a specific fee.",
        school_opts,
    )


# ── Documents ─────────────────────────────────────────────────────────────────

def documents_query_validation(query: str) -> Dict[str, Any]:
    q = (query or "").lower()

    if len(q.split()) <= 1:
        return _clarify("Could you provide a bit more detail about your question?")

    has_topic    = _match(_patterns.docs_topic, q)
    has_doc_type = _match(_patterns.docs_type, q)
    has_generic_doc = bool(_GENERIC_DOC.search(q))

    if has_topic or has_doc_type:
        return {"needs_clarification": False, "options": []}

    # Long policy-style queries that don't match curated keywords — let retrieval attempt an answer.
    if len(q.split()) >= 5 and not has_generic_doc:
        return {"needs_clarification": False, "options": []}

    return _clarify(
        "Could you specify what university policy or document you are looking for? "
        "For example: GPA requirements, housing policy, visa rules, or academic probation."
    )
